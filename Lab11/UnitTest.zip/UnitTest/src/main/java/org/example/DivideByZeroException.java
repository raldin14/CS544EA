package org.example;

public class DivideByZeroException extends RuntimeException {
}
